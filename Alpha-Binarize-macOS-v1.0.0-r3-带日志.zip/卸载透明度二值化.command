#!/bin/bash
set -euo pipefail
if [[ "$(/usr/bin/uname -s)" != Darwin || "$(/usr/bin/id -u)" == 0 ]]; then
  echo "请在 Mac 上以普通用户运行卸载工具。"; exit 1
fi
target="$HOME/Library/Application Support/Adobe/CEP/extensions/com.alpha.binarize.panel"
support="$HOME/Library/Application Support/Alpha-Binarize"
if /usr/bin/pgrep -f '/Adobe Photoshop[^/]*\.app/Contents/MacOS/' >/dev/null; then
  echo "请先退出 Photoshop，再运行卸载。"; exit 1
fi
answer=$(/usr/bin/osascript -e 'display dialog "卸载当前用户的透明度二值化面板？插件将移入备份目录。" buttons {"取消", "卸载"} default button "卸载" cancel button "取消"')
if [[ -L "$target" || -L "$support" ]]; then echo "发现符号链接，停止卸载。"; exit 1; fi
if [[ -d "$target" ]]; then
  /bin/mkdir -p "$support/Backups"
  backup=$(/usr/bin/mktemp -d "$support/Backups/uninstalled-XXXXXXXX")
  /bin/mv "$target" "$backup/com.alpha.binarize.panel"
  echo "卸载完成，插件已备份至：$backup"
else
  echo "当前用户没有安装此面板。"
fi
echo "CEP 共享加载设置已保留。"
read -r -p "按回车关闭。" _

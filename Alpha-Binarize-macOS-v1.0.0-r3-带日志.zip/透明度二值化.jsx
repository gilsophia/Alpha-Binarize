﻿// ─────────────────────────────────────────────────────────────────────────────
//  图层透明度二值化（alpha-binarize.jsx）
//  安装：PS 菜单 [文件 > 脚本 > 浏览…] 选择本文件；
//        或把本文件复制到 Photoshop 安装目录的 Presets\Scripts\ 下，
//        之后即可在 [文件 > 脚本] 菜单里直接运行。
//  作用：把选中图层每个像素的不透明度(alpha)按阈值强制为 0 或 255，
//        即 0%（完全透明）或 100%（完全不透明）；默认直接烘焙进图层像素，
//        可选把颜色也二值化为纯黑/纯白。整次操作可用一次 Ctrl+Z 撤销。
//  实测兼容：Photoshop 2020 (21.2) 中文版。
// ─────────────────────────────────────────────────────────────────────────────

function notify(message) {
    if (typeof BINARIZE_ALPHA_SILENT !== "undefined" && BINARIZE_ALPHA_SILENT) {
        $.writeln(message);
        return;
    }
    alert(message);
}

function normalizeThreshold(value) {
    var threshold = parseInt(value, 10);
    if (isNaN(threshold)) threshold = 128;
    if (threshold < 1) threshold = 1;
    if (threshold > 255) threshold = 255;
    return threshold;
}

// 对目标图层像素应用 图像 > 调整 > 阈值（只改 RGB，不改 alpha）
function applyThresholdToLayer(level) {
    var thresholdEvent = charIDToTypeID("Thrs");
    var desc = new ActionDescriptor();
    var targetRef = new ActionReference();
    targetRef.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc.putReference(charIDToTypeID("null"), targetRef);
    var settings = new ActionDescriptor();
    settings.putDouble(charIDToTypeID("Lvl "), level);
    desc.putObject(charIDToTypeID("Usng"), thresholdEvent, settings);
    executeAction(thresholdEvent, desc, DialogModes.NO);
}

// 图层 > 图层蒙版 > 从透明度建立：把图层 alpha 读进蒙版，图层内容变为不透明
function createMaskFromTransparency() {
    var desc = new ActionDescriptor();
    desc.putClass(charIDToTypeID("Nw  "), charIDToTypeID("Chnl"));
    var maskRef = new ActionReference();
    maskRef.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Msk "));
    desc.putReference(charIDToTypeID("At  "), maskRef);
    desc.putEnumerated(charIDToTypeID("Usng"), charIDToTypeID("UsrM"), charIDToTypeID("Trns"));
    executeAction(charIDToTypeID("Mk  "), desc, DialogModes.NO);
}

// 选中当前图层的图层蒙版
function selectLayerMask() {
    var desc = new ActionDescriptor();
    var maskRef = new ActionReference();
    maskRef.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Msk "));
    desc.putReference(charIDToTypeID("null"), maskRef);
    desc.putBoolean(charIDToTypeID("MkVs"), false);
    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
}

// 对当前选中的蒙版应用 阈值：像素 >= level 变 255，< level 变 0
function thresholdSelectedChannel(level) {
    var thresholdEvent = charIDToTypeID("Thrs");
    var desc = new ActionDescriptor();
    var channelRef = new ActionReference();
    channelRef.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));
    desc.putReference(charIDToTypeID("null"), channelRef);
    var settings = new ActionDescriptor();
    settings.putDouble(charIDToTypeID("Lvl "), level);
    desc.putObject(charIDToTypeID("Usng"), thresholdEvent, settings);
    executeAction(thresholdEvent, desc, DialogModes.NO);
}

// 图层 > 图层蒙版 > 应用：把蒙版烘焙进像素并删除蒙版
function applyLayerMask() {
    var desc = new ActionDescriptor();
    var targetRef = new ActionReference();
    targetRef.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    desc.putReference(charIDToTypeID("null"), targetRef);
    desc.putBoolean(charIDToTypeID("Aply"), true);
    executeAction(charIDToTypeID("Dlt "), desc, DialogModes.NO);
}

// 探测当前图层是否已有图层蒙版（UsrM 属性）
function layerHasMask() {
    try {
        var ref = new ActionReference();
        var keyUsrM = charIDToTypeID("UsrM");
        ref.putProperty(charIDToTypeID("Prpr"), keyUsrM);
        ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        var desc = executeActionGet(ref);
        return desc.hasKey(keyUsrM);
    } catch (e) {
        return false;
    }
}

// 读取当前活动图层的 ID
function getActiveLayerID() {
    var ref = new ActionReference();
    ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    var desc = executeActionGet(ref);
    return desc.getInteger(stringIDToTypeID("layerID"));
}

// 按图层 ID 选中该图层（会清理残留的蒙版/通道选择状态，保证后续命令可用）
function selectLayerByID(id) {
    var desc = new ActionDescriptor();
    var ref = new ActionReference();
    ref.putIdentifier(charIDToTypeID("Lyr "), id);
    desc.putReference(charIDToTypeID("null"), ref);
    desc.putBoolean(charIDToTypeID("MkVs"), false);
    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
}

function activateLayer(layer, layerId) {
    if (layerId >= 0) {
        try {
            selectLayerByID(layerId);
            return;
        } catch (idSelectError) {}
    }
    app.activeDocument.activeLayer = layer;
    try {
        var id = getActiveLayerID();
        selectLayerByID(id);
    } catch (activationError) {}
}

// 读取当前选中的图层（老版本没有 activeLayers 属性：targetLayers 列表里
// 有的是带 layerID 的对象项，有的是相对索引的引用项）。
// 返回 [{layer: 图层对象, id: 图层ID}]，ID 用于可靠地激活图层。
function getSelectedLayers(doc) {
    var selected = [];
    try {
        var bgCounter = 1;
        try {
            var lastArt = doc.artLayers[doc.artLayers.length - 1];
            if (lastArt && lastArt.isBackgroundLayer) bgCounter = 0;
        } catch (artError) {}
        var ref = new ActionReference();
        ref.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("targetLayers"));
        ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("targetLayers"))) {
            var list = desc.getList(stringIDToTypeID("targetLayers"));
            for (var i = 0; i < list.count; i++) {
                var found = null;
                var foundId = -1;
                try {
                    var item = list.getObjectValue(i);
                    if (item.hasKey(stringIDToTypeID("layerID"))) {
                        foundId = item.getInteger(stringIDToTypeID("layerID"));
                        found = doc.layers.getById(foundId);
                    }
                } catch (objError) {
                    try {
                        var lr = list.getReference(i);
                        var putIndexValue = lr.getIndex() + bgCounter;
                        var selDesc = new ActionDescriptor();
                        var selRef = new ActionReference();
                        selRef.putIndex(charIDToTypeID("Lyr "), putIndexValue);
                        selDesc.putReference(charIDToTypeID("null"), selRef);
                        selDesc.putBoolean(charIDToTypeID("MkVs"), false);
                        executeAction(charIDToTypeID("slct"), selDesc, DialogModes.NO);
                        found = doc.activeLayer;
                        try {
                            foundId = getActiveLayerID();
                        } catch (idError) {}
                    } catch (refError) {}
                }
                if (found) selected.push({ layer: found, id: foundId });
            }
        }
    } catch (queryError) {}
    if (selected.length === 0) {
        selected.push({ layer: doc.activeLayer, id: -1 });
    }
    return selected;
}

// 只统计选中图层数量（不改变选择状态，供对话框提示用）
function countSelectedLayers() {
    try {
        var ref = new ActionReference();
        ref.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("targetLayers"));
        ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("targetLayers"))) {
            return desc.getList(stringIDToTypeID("targetLayers")).count;
        }
    } catch (e) {}
    return 1;
}

function binarizeSelectedLayers(threshold, alsoRGB, keepMask) {
    var doc = app.activeDocument;
    var targets = getSelectedLayers(doc);
    var warnings = [];
    for (var i = 0; i < targets.length; i++) {
        var layer = targets[i].layer;
        var layerId = targets[i].id;
        var layerName = layer.name;
        try {
            activateLayer(layer, layerId);
            if (layer.typename === "LayerSet") {
                warnings.push(layerName + "：图层组不支持，请选择组内的具体图层。");
                continue;
            }
            if (alsoRGB) {
                try {
                    applyThresholdToLayer(threshold);
                } catch (colorError) {
                    try {
                        activateLayer(layer, layerId);
                        applyThresholdToLayer(threshold);
                    } catch (colorError2) {
                        warnings.push(layerName + "：颜色二值化失败（" + colorError2.message + "）。");
                    }
                }
            }
            if (layer.isBackgroundLayer) {
                continue;
            }
            if (layerHasMask()) {
                warnings.push(layerName + "：已有图层蒙版，已跳过透明度二值化（请先删除原蒙版再运行）。");
                continue;
            }
            createMaskFromTransparency();
            selectLayerMask();
            thresholdSelectedChannel(threshold);
            if (!keepMask) {
                applyLayerMask();
            }
        } catch (layerError) {
            warnings.push(layerName + "：" + layerError.message + "。");
        }
    }
    if (warnings.length > 0) {
        notify("处理完成，但有以下提示：\n\n" + warnings.join("\n"));
    }
    return warnings.join("\n");
}

function runBinarize(threshold, alsoRGB, keepMask) {
    app.activeDocument.suspendHistory(
        "图层透明度二值化",
        "binarizeSelectedLayers(" + threshold + ", " + alsoRGB + ", " + keepMask + ")"
    );
}

function showBinarizeDialog() {
    app.bringToFront();
    var savedThreshold = 128;
    var savedRGB = false;
    var savedKeepMask = false;
    try {
        var savedOptions = app.getCustomOptions("alphaBinarize");
        savedThreshold = savedOptions.getInteger(stringIDToTypeID("threshold"));
        savedRGB = savedOptions.getBoolean(stringIDToTypeID("alsoRGB"));
        savedKeepMask = savedOptions.getBoolean(stringIDToTypeID("keepMask"));
    } catch (optionError) {}

    var doc = app.activeDocument;
    var dlg = new Window("dialog", "图层透明度二值化");
    dlg.orientation = "column";
    dlg.alignChildren = ["fill", "top"];
    dlg.spacing = 10;
    dlg.margins = 16;

    var panel = dlg.add("panel", undefined, "透明度阈值（1 - 255）");
    panel.orientation = "row";
    panel.alignChildren = ["fill", "center"];
    panel.spacing = 10;
    var slider = panel.add("slider", undefined, savedThreshold, 1, 255);
    slider.preferredSize.width = 200;
    var edit = panel.add("edittext", undefined, String(savedThreshold));
    edit.characters = 4;

    slider.onChanging = function () {
        edit.text = String(Math.round(slider.value));
    };
    edit.onChanging = function () {
        var value = parseInt(edit.text, 10);
        if (!isNaN(value)) {
            if (value < 1) value = 1;
            if (value > 255) value = 255;
            slider.value = value;
        }
    };

    var rgbBox = dlg.add("checkbox", undefined, "同时把颜色二值化为纯黑 / 纯白");
    rgbBox.value = savedRGB;

    var keepBox = dlg.add("checkbox", undefined, "保留图层蒙版（不烘焙，便于之后手绘微调）");
    keepBox.value = savedKeepMask;

    var hint = dlg.add("statictext", undefined, "将对选中的 " + countSelectedLayers() + " 个图层执行：透明度 ≥ 阈值的像素变为 100% 不透明，透明度 < 阈值的像素变为完全透明。");
    hint.preferredSize.width = 320;

    var buttons = dlg.add("group");
    buttons.alignment = "right";
    buttons.add("button", undefined, "取消", { name: "cancel" });
    buttons.add("button", undefined, "执行", { name: "ok" });

    dlg.center();
    if (dlg.show() !== 1) return;

    var threshold = normalizeThreshold(edit.text);
    var alsoRGB = rgbBox.value;
    var keepMask = keepBox.value;

    try {
        var options = new ActionDescriptor();
        options.putInteger(stringIDToTypeID("threshold"), threshold);
        options.putBoolean(stringIDToTypeID("alsoRGB"), alsoRGB);
        options.putBoolean(stringIDToTypeID("keepMask"), keepMask);
        app.putCustomOptions("alphaBinarize", options, true);
    } catch (optionError) {}

    runBinarize(threshold, alsoRGB, keepMask);
}

if (typeof BINARIZE_ALPHA_SILENT === "undefined") {
    if (app.documents.length === 0) {
        alert("请先打开一个文档，再运行本脚本。");
    } else {
        showBinarizeDialog();
    }
}
